//
//  PosterCell.swift
//  MovieCo
//
//  Created by Arely Correa on 2/13/24.
//

import UIKit

class PosterCell: UICollectionViewCell {
    
    @IBOutlet weak var posterImageView: UIImageView!
    
}
